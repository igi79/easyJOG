#pragma once

#include "Multiplexed/EncPlex74165.h"
#include "Multiplexed/EncPlex4067.h"
#include "Multiplexed/EncPlex4051.h"
#include "Single/Encoder.h"
#include "Single/PolledEncoder.h"
